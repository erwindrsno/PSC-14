public interface RouletteWheel {
    void selectParents();
}