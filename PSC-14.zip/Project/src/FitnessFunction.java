public interface FitnessFunction {
    void calculateFitness();
}